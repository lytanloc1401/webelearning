
<?php
   session_start();
   require_once("../../db.php");
?>
<!DOCTYPE html>
<html>
<head>
<title>TDTU Learing System</title>
<link rel="shortcut icon" type="image/x-icon" href="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSQTSi6uJra_mrOlMQ8ztytEkqnxcFDCUSj0w&usqp=CAU" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
<script src="JS/FormHomeActivity.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  </script>
</head>

<body>
<nav class="navbar navbar-expand-md bg-dark navbar-dark">
        <div class="container-fluid">
        <a class="navbar-brand"></a>
        <ul class="nav navbar-nav navbar-right">  
        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Add
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="add.php">Exercises</a>
          <a class="dropdown-item" href="../lesson/add.php">Lession</a>  
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="../../FormLogout.php">Logout</a>
        </li>
    </ul>
  </div>
</nav>
<div class="container" style="margin-top: 60px; margin-left: 10px; background-color: #d4d1cd ">
			<div class="row">
				<div class="col-sm-3">
					<ul class="list-group">
						<li class="list-group-item"><a href="../FormHomeActivity.php">Dashboard</a></li>
						<li class="list-group-item"><a href="../lesson/FormLesson.php">Lesson</a></li>
						<li class="list-group-item"><a href="FormExercise.php">Exercises</a></li>
                    </ul>
                    <ul class="list-group">
						<li class="list-group-item"><a href="../Gallery/FormGallery.php">Galery</a></li>
						<li class="list-group-item"><a href="../student/FormStudent.php">Manage Students</a></li>
						<li class="list-group-item"><a href="../user/FormUser.php">Manage Users</a></li>
					</ul>
				</div>
				<div class="col-sm-9">
                <form class="form-horizontal span6" action="" method="POST" style="margin-top: 20px;"> 
                        <div class="row">
                           <div class="col-lg-12">
                              <h1 class="page-header">Add New Exercises</h1>
                            </div>
                            <!-- /.col-lg-12 -->
                         </div>
                         <div class="form-group">
                        <div class="col-md-8">
                          <label class="col-md-4 control-label">ExerciseID</label>

                          <div class="col-md-8">
                          <input type="text">
                         </div>
                        </div>
                      </div>
                        <div class="form-group">
                        <div class="col-md-8">
                          <label class="col-md-4 control-label" for=
                          "Lesson">LessonID:</label>

                          <div class="col-md-8"> 
                            <select class="form-control" name="Lesson">
                              <?php
                                    $sql = "SELECT LessonID FROM tbllesson";
                                    $result = $conn->query($sql);
                                    if(mysqli_num_rows($result)  > 0){
                                      while($row = mysqli_fetch_assoc($result)){
                                        echo $row["LessonID"] . "<br>";
                                      }
                                    }else{
                                      echo "0 results";
                                    }
                              ?>
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="col-md-8">
                          <label class="col-md-4 control-label" for="IDsubject">IDsubject:</label>

                          <div class="col-md-8"> 
                            <select class="form-control" name="IDsubject">

                            </select>
                          </div>
                        </div>
                      </div>
                      
                       <div class="form-group">
                        <div class="col-md-8">
                          <label class="col-md-4 control-label">chọn ngày hạn:</label>

                          <div class="col-md-8">
                          <input type="text" id="datepicker" >
                         </div>
                        </div>
                      </div>
                    <div class="col-md-8">
                           <button class="btn btn-primary btn-sm" name="save" type="submit" ><span class="fa fa-save fw-fa"></span> Save</button> 
                           </div>
                        </div>
                      </div> 
                      </form>                
				</div>
			</div>
		</div>
</body>