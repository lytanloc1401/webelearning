<div class="col-sm-3 sidebar">
    <ul class="list-group">
        <li class="list-group-item"><a href="/finalProjectWEB/admin/FormHomeActivity.php">Dashboard</a></li>
        <li class="list-group-item"><a href="/finalProjectWEB/admin/lesson/FormLesson.php">Lesson</a></li>
        <li class="list-group-item"><a href="/finalProjectWEB/admin/Exercise/FormExercise.php">Exercises</a></li>
        <li class="list-group-item"><a href="/finalProjectWEB/admin/Gallery/FormGallery.php">Galery</a></li>
        <li class="list-group-item"><a href="/finalProjectWEB/admin/student/FormStudent.php">Manage Students</a></li>
        <li class="list-group-item"><a href="/finalProjectWEB/admin/user/FormUser.php">Manage Users</a></li>
    </ul>
</div>