<?php
  session_start();
  if (!isset($_SESSION['user'])) {
    header('Location: ../FormLogin.php');
    exit();
}
require_once("../db.php");
?>
<!DOCTYPE html>
<html>
<head>
<title>TDTU Learing System</title>
<link rel="shortcut icon" type="image/x-icon" href="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSQTSi6uJra_mrOlMQ8ztytEkqnxcFDCUSj0w&usqp=CAU" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="CSS/Index.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
<script src="JS/Index.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</head>
<body>
<nav class="navbar navbar-expand-md bg-dark navbar-dark">
<a class="navbar-brand" href="#">Class</a>

        <div class="container-fluid">
            <div class="dropdown">
              <button onclick="myFunction()" class="dropbtn btn btn-primary"><i class="fa fa-list" aria-hidden="true"></i></button>
              <div id="myDropdown" class="dropdown-content">
                <a class="dropdown-item" href="#home">+</a>
                <a class="dropdown-item" href="#about">-</a>
                <a class="dropdown-item" href="#contact">...</a>
              </div>
            </div>
       
              


      <ul class="list-inline">
        <li class="list-inline-item">
          <button class="add btn btn-primary" data-toggle="modal" data-target="#addCourseModal">
            <i class="fa fa-plus-circle" aria-hidden="true"></i>
          </button>
        </li>
        <li class="list-inline-item">
          <a class="na" href="../FormLogout.php">
                <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-box-arrow-in-right" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                  <path fill-rule="evenodd" d="M6 3.5a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-2a.5.5 0 0 0-1 0v2A1.5 1.5 0 0 0 6.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-8A1.5 1.5 0 0 0 5 3.5v2a.5.5 0 0 0 1 0v-2z"/>
                  <path fill-rule="evenodd" d="M11.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H1.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3z"/>
                </svg>
            </a>
        </li>
      </ul>

    </div>  
  </div>
</nav>
<div class="container">

    <!-- dòng phải là con trực tiếp của container, mang class row -->
    <div class="row">

<?php
  $db = new PDO('mysql:host=localhost;dbname=db_elearning', 'root', '');
  $db->query("set names utf8");
	//thuc hien cau truy van
  $course = $db->query('select * from tblsubjects');
?>  

<?php
  foreach ($course as $item) {
    
    // echo "<pre>";
    // print_r ($item);
    // echo "</pre>";?>
    
            <div class="col-sm-3 col-md-3 col-lg-3 col-xl-3">
            <div class="card shadow mt-5">
                <div class="card-body">
                  <a  href="FormHomeActivity.php"> <h4 class="card-title"><?php echo $item['Subjects'];  ?></h4></a>
                  <a  href="FormHomeActivity.php"> <p class="card-text"><?php echo $item['Teacher']; ?></p> </a>
                  <a  href="FormHomeActivity.php"> <p class="card-text"><?php echo $item['ID']; ?></p> </a>
                  <a  href="FormHomeActivity.php"> <img class="mw-100" src="../image/avatarclass.png" alt="avatar"></a>
                    </div>
                </div>
            </div>


<?php  }?>

      <!-- cột 1 -->

</div>
<div class="modal" tabindex="-1" id="addCourseModal" role="dialog">
  <form class="modal-dialog" role="document" action="Index.php" method="post">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Create course</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <div class="form-group">
            <input type="text" class="form-control" name="course_name" placeholder="Course's name"/>
          </div>
          <div class="form-group">
            <input type="text" class="form-control" name="teacher" placeholder="Teacher"/>
          </div>
          <div class="form-group">
            <input type="text" class="form-control" name="ID" placeholder="ID"/>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button name="create" type="submit" class="btn btn-primary">Create</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
</form>
</div>
<!-- create bảng-->
<?php	
      if (isset($_POST["create"])) 
      {
  			//get form information
  			$id = $_POST["ID"];
  			$course_name = $_POST["course_name"];
 			  $teacher = $_POST["teacher"];
			

  			//test
			  if ($id == "" || $course_name == "" || $teacher == "") {
				   echo "please, enter your information";
  			}else{
  					// test account exist
  					$sql1="SELECT * FROM tblsubjects WHERE ID='$id'";
					$kt=mysqli_query($conn, $sql1);

					if(mysqli_num_rows($kt)  > 0){
						echo "subjects exist";
					}else{
	    				$sql = "INSERT INTO tblsubjects(
	    					ID,
	    					Subjects,
	    					Teacher
	    					) VALUES (
	    					'$id',
	    					'$course_name',
	    					'$teacher'
	    					)";
               mysqli_query($conn,$sql);          
              }
									    
					
			  }
      }
?>

</body>
</html>
