<?php
  session_start();
  if (!isset($_SESSION['user'])) {
    header('Location: ../FormLogin.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
<title>TDTU Learing System</title>
<link rel="shortcut icon" type="image/x-icon" href="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSQTSi6uJra_mrOlMQ8ztytEkqnxcFDCUSj0w&usqp=CAU" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="CSS/FormHomeActivity.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
<script src="JS/FormHomeActivity.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</head>
<body>
<nav class="navbar navbar-expand-md bg-dark navbar-dark">
        <div class="container-fluid">
        <a class="navbar-brand"></a>
        <ul class="nav navbar-nav navbar-right">  
        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Add
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="../Exercise/add.php">Exercises</a>
          <a class="dropdown-item" href="../lesson/add.php">Lession</a>  
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="../../FormLogout.php">Logout</a>
        </li>
    </ul>
  </div>
</nav>
<div class="container" style="margin-top: 60px;  margin-left: 10px; background-color: #d4d1cd ">
			<div class="row">
				<div class="col-sm-3">
					<ul class="list-group">
						<li class="list-group-item"><a href="../FormHomeActivity.php">Dashboard</a></li>
						<li class="list-group-item"><a href="../lesson/FormLesson.php">Lesson</a></li>
						<li class="list-group-item"><a href="../Exercise/FormExercise.php">Exercises</a></li>
                    </ul>
                    <ul class="list-group">
						<li class="list-group-item"><a href="../Gallery/FormGallery.php">Galery</a></li>
						<li class="list-group-item"><a href="../student/FormStudent.php">Manage Students</a></li>
						<li class="list-group-item"><a href="FormUser.php">Manage Users</a></li>
					</ul>
				</div>
				<div class="col-sm-9">
				<div style="background-color: white ">
                    <form class="form-horizontal span6" action="" method="POST" onsubmit="return validatedpass()">
                    <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Add New User</h1>
                    </div>
                    <!-- /.col-lg-12 -->
                </div> 
                                <!-- <div class="form-group">
                                <div class="col-md-8">
                                <label class="col-md-4 control-label" for=
                                "user_id">User Id:</label>

                                <div class="col-md-8"> --> 
                                    <!--  <input class="form-control input-sm" id="user_id" name="user_id" placeholder=
                                        "Account Id" type="hidden" value="<?php echo $res->AUTO; ?>"> -->
                                <!--   </div>
                                </div>
                            </div> -->           
                            
                            <div class="form-group">
                                <div class="col-md-8">
                                <label class="col-md-4 control-label" for=
                                "user_name">Name:</label>

                                <div class="col-md-8">
                                    <input name="deptid" type="hidden" value="">
                                    <input class="form-control input-sm" id="user_name" name="user_name" placeholder=
                                        "Account Name" type="text" value="">
                                </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-8">
                                <label class="col-md-4 control-label" for=
                                "user_email">Username:</label>

                                <div class="col-md-8">
                                    <input name="deptid" type="hidden" value="">
                                    <input class="form-control input-sm" id="user_email" name="user_email" placeholder=
                                        "Username" type="text" value="">
                                </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-8">
                                <label class="col-md-4 control-label" for=
                                "user_pass">Password:</label>

                                <div class="col-md-8">
                                    <input name="deptid" type="hidden" value="">
                                    <input class="form-control input-sm" id="user_pass" name="user_pass" placeholder=
                                        "Account Password" type="Password" value="">
                                </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-8">
                                <label class="col-md-4 control-label" for=
                                "user_pass">Retype Password:</label>

                                <div class="col-md-8">
                                    <input name="deptid" type="hidden" value="">
                                    <input class="form-control input-sm" id="retype_user_pass" name="retype_user_pass" placeholder=
                                        "Retype Password" type="Password" value="">
                                </div>
                                </div>
                            </div>
                        <!--    <div class="form-group">
                                <div class="col-md-8">
                                <label class="col-md-4 control-label" for=
                                "user_type">Type:</label>

                                <div class="col-md-8">
                                <select class="form-control input-sm" name="user_type" id="user_type">
                                    <option value="Administrator">Administrator</option>
                                    <option value="Staff">Staff</option> 
                                    <option value="Customer">Customer</option>
                                    <option value="Encoder">Encoder</option>
                                    </select> 
                                </div>
                                </div>
                            </div> -->

                        
                        <div class="form-group">
                                <div class="col-md-8">
                                <label class="col-md-4 control-label" for=
                                "idno"></label>

                                <div class="col-md-8">
                                <button class="btn btn_kcctc" id="usersave" name="save" type="submit" ><strong>Save</strong></button> 
                                    <a href="index.php" class="btn btn_kcctc"><span class="glyphicon glyphicon-arrow-left"></span>&nbsp;<strong>List of Users</strong></a>
                                </div>
                                </div>
                            </div>

                    
                    
                    </form>
               
                </div>
				</div>
			</div>
		</div>
</body>